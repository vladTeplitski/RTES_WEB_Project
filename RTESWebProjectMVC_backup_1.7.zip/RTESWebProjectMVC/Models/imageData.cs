﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RTESWebProjectMVC.Models
{
    public class imageData
    {

        public int id { get; set; }

        public int imgid { get; set; }
        public byte[] picture { get; set; }

    }
}