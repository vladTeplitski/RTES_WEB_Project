﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RTESWebProjectMVC.Models
{
    public class driverDetails
    {
        public String name { get; set; }
        public int cargo { get; set; }
        public String phone { get; set; }
    }
}